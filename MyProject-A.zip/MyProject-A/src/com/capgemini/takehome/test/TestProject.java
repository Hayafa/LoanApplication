package com.capgemini.takehome.test;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.jupiter.api.Test;

import com.capgemini.takehome.bean.Product;
import com.capgemini.takehome.dao.IProductDAO;
import com.capgemini.takehome.dao.ProductDAO;
import com.capgemini.takehome.services.IProductServices;
import com.capgemini.takehome.services.ProductService;

class TestProject {

	private static IProductDAO productDao;
	
	@BeforeClass
	public static void setUpTestEnv(){
		productDao=new ProductDAO();
	}
	
	@Before
	public void setUpTestData() {
		Product product=new Product(1001,);
	}
	
	@Test
	void test() {
		
	}

}
