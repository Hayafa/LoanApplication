package com.capgemini.takehome.services;

import com.capgemini.takehome.bean.Product;

public interface IProductServices {

	Product getProductDetails(int ProductCode);
}
