package com.capgemini.takehome.services;

import com.capgemini.takehome.bean.Product;
import com.capgemini.takehome.dao.IProductDAO;
import com.capgemini.takehome.dao.ProductDAO;

public class ProductService implements IProductServices {

	IProductDAO productDao= new ProductDAO();
	@Override
	public Product getProductDetails(int ProductCode) {
		Product product=null;
		
		if(ProductCode==1001 || ProductCode==1002 || ProductCode==1003 || ProductCode==1004)
			return product;
		else {
			try {
				throw new Error();
		    	} catch (Error e) {
				System.out.println("Sorry! The ProductCode <<"+ProductCode+">> is not available");
				e.printStackTrace();
			    }
		   }
		product=productDao.getProductDetails(ProductCode);
		return product;
	}
}
