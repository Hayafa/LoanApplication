package com.capgemini.takehome.ui;

import java.util.Scanner;

import com.capgemini.takehome.bean.Product;
import com.capgemini.takehome.exceptions.InsufficientQuantityException;
import com.capgemini.takehome.exceptions.InvalidProductCodeException;
import com.capgemini.takehome.services.IProductServices;
import com.capgemini.takehome.services.ProductService;

public class Client {

	public static void main(String[] args) {

		IProductServices productserv=new ProductService();
		Product product=null;
		int input=0;

		System.out.println("---------------------Billing Software Application-----------------------");
		System.out.println("Choose your option:\n1) Generate Bill by entering Product code and quantity\n2) Exit");
		Scanner sc=new Scanner(System.in);

		while(input!=2) {
			input=sc.nextInt();
			switch(input)
			{
			case 1:
				System.out.println("Enter Product Details-\nEnter the productCode");
				int pCode=sc.nextInt();
				if(pCode<=999 || pCode>=9999)
					try {
						throw new InvalidProductCodeException();
					} catch (InvalidProductCodeException e) {
						e.printStackTrace();System.exit(0);
					}
				System.out.println("Enter the quantity");
				int quantity=sc.nextInt();
				if(quantity<=0)
					try {
						throw new InsufficientQuantityException();
					} catch (InsufficientQuantityException e) {
						e.printStackTrace();System.exit(0);
					}

				try {
					product=productserv.getProductDetails(pCode);
				} catch (Error e) {
					e.printStackTrace();
				}

				System.out.println("Product Information:\nProduct Name:"+product.getProductName()+"\nProduct Category:"+
						product.getProductCategory()+"\nProduct Description:"+product.getProductDescription()+
						"\nProduct price(Rs):"+product.getProductPrice()+"\nQuantity:"+quantity+"\nLine Total(Rs):"+(quantity*product.getProductPrice()));
				break;	
			case 2: System.out.println("Status:Exit");System.exit(0);
			default: System.out.println("Invalid entry! Enter your option again.");continue;
			}
		}
	}

}
