package com.capgemini.salesmanagement.ui;

import java.util.Scanner;

import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.exceptions.InvalidProductCategoryException;
import com.capgemini.salesmanagement.exceptions.InvalidProductCodeException;
import com.capgemini.salesmanagement.exceptions.InvalidProductNameException;
import com.capgemini.salesmanagement.exceptions.InvalidProductPriceException;
import com.capgemini.salesmanagement.service.SaleService;

public class Client {

	public static void main(String[] args) {
		
		SaleService services=new SaleService();
		Sale beanssale=new Sale();
		Scanner sc=new Scanner(System.in);
		int sum=0;
		int nowWhat=0;

		System.out.println("----------------------Billing Software Application-------------------------\n");
		System.out.println("1)Enter Product Details\n2)Exit");
		int whattodo=sc.nextInt();
		
		while(nowWhat!=2){

			switch(whattodo) {
			case 1:{
				
				System.out.println("Enter the product code:");
				int pCode=sc.nextInt();
				if(services.validateProductCode(pCode)==false)
					try {
						throw new InvalidProductCodeException();
					} catch (InvalidProductCodeException e) {
						e.printStackTrace();System.exit(0);
					}

				System.out.println("Product Category:");
				String pCat=sc.next();
				services.insertSalesDetails(beanssale);

				if(services.validateProductCat(pCat)==false)
					try {
						throw new InvalidProductCategoryException();
					} catch (InvalidProductCategoryException e) {
						// TODO Auto-generated catch block
						System.out.println(e.getMessage());System.exit(0);
					}

				System.out.println("Product Name:");
				String pName=sc.next();

				if(services.validateProductName(pName,pCat)==false)
					try {
						throw new InvalidProductNameException();
					} catch (InvalidProductNameException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();System.exit(0);
					}

				System.out.println("Product Description:");
				String pDesc=sc.next();

				System.out.println("Product Price():");
				int pPrice=sc.nextInt();
				if(services.validateProductPrice(pPrice)==false)
					try {
						throw new InvalidProductPriceException();
					} catch (InvalidProductPriceException e) {
						e.printStackTrace();System.exit(0);
					}

				System.out.println("Quantity");
				int quant=sc.nextInt();

				int lineTotal=pPrice*quant;
				sum+=lineTotal;

				System.out.println("Line Total:\n"+lineTotal);
				beanssale=new Sale(pCode,quant,pPrice,pCat,pName,pDesc,lineTotal);
				services.insertSalesDetails(beanssale);

				System.out.println(beanssale);break;}
			case 2:System.out.println("Status:exit!");System.exit(0);
			default: System.out.println("Invalid entry! Please enter again.");
			}
			System.out.println("\n       Select your option         "
					+ "   \n1)Continue    or    2)Exit");
			 nowWhat=sc.nextInt();
		}

		System.out.println("Total Bill to pay:"+sum);

	}

}
