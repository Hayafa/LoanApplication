package com.capgemini.salesmanagement.service;

import java.util.HashMap;

import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.dao.ISaleDAO;
import com.capgemini.salesmanagement.dao.SaleDAO;

public class SaleService implements ISaleService{
	
    ISaleDAO saleDao=new SaleDAO();
    Sale saleBeans=new Sale();
  
    
	@Override
	public HashMap<Integer, Sale> insertSalesDetails(Sale sale) {
		
		return saleDao.insertSalesDetails(sale);
	}

	@Override
	public boolean validateProductCode(int productId) {
		if(productId>=1001 && productId<=1004)
			return true;
		else
		    return false;
	}

	@Override
	public boolean validateQuantity(int qty) {
		if(qty>0 && qty<5)
			return true;
		else
		    return false;
	}

	@Override
	public boolean validateProductCat(String prodCat) {
		if(prodCat.equalsIgnoreCase("ELECTRONICS") || prodCat.equalsIgnoreCase("TOYS"))
		    return true;
		else
			return false;
	}

	@Override
	public boolean validateProductName(String prodName,String pCat) {
		if(pCat.equalsIgnoreCase("ELECTRONICS"))
		{
			if(prodName.equalsIgnoreCase("TV") || prodName.equalsIgnoreCase("SmartPhone") || 
					prodName.equalsIgnoreCase("VideoGame"))
				return true;
		}
		else if(pCat.equalsIgnoreCase("TOYS"))
		{
			if(prodName.equalsIgnoreCase("SOFTTOY") || prodName.equalsIgnoreCase("TELESCOPE") || 
					prodName.equalsIgnoreCase("BARBIEDOLL"))
				return true;
		}
		return false;
	}

	@Override
	public boolean validateProductPrice(float price) {
		if(price>200)
			return true;
		else
			return false;
	}

}
