package com.capgemini.salesmanagement.bean;

import java.time.LocalDate;

public class Sale {

	private int saleId;
	int pCode,quantity,productPrice;
	String category,pName,description;
	private LocalDate sale_date;
	float lineTotal;
	public Sale() {
		super();
	}
	
	public Sale(int pCode, int quantity, int productPrice, String category, String pName, String description,
			float lineTotal) {
		super();
		this.pCode = pCode;
		this.quantity = quantity;
		this.productPrice = productPrice;
		this.category = category;
		this.pName = pName;
		this.description = description;
		this.lineTotal = lineTotal;
	}

	public Sale(int saleId, int pCode, int quantity, int productPrice, String category, String pName,
			String description, LocalDate sale_date, float lineTotal) {
		super();
		this.saleId = saleId;
		this.pCode = pCode;
		this.quantity = quantity;
		this.productPrice = productPrice;
		this.category = category;
		this.pName = pName;
		this.description = description;
		this.sale_date = sale_date;
		this.lineTotal = lineTotal;
	}
	public int getSaleId() {
		return saleId;
	}
	public void setSaleId(int saleId) {
		this.saleId = saleId;
	}
	public int getpCode() {
		return pCode;
	}
	public void setpCode(int pCode) {
		this.pCode = pCode;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public int getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getpName() {
		return pName;
	}
	public void setpName(String pName) {
		this.pName = pName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public LocalDate getSale_date() {
		return sale_date;
	}
	public void setSale_date(LocalDate sale_date) {
		this.sale_date = sale_date;
	}
	public float getLineTotal() {
		return lineTotal;
	}
	public void setLineTotal(float lineTotal) {
		this.lineTotal = lineTotal;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((category == null) ? 0 : category.hashCode());
		result = prime * result + ((description == null) ? 0 : description.hashCode());
		result = prime * result + Float.floatToIntBits(lineTotal);
		result = prime * result + pCode;
		result = prime * result + ((pName == null) ? 0 : pName.hashCode());
		result = prime * result + productPrice;
		result = prime * result + quantity;
		result = prime * result + saleId;
		result = prime * result + ((sale_date == null) ? 0 : sale_date.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Sale other = (Sale) obj;
		if (category == null) {
			if (other.category != null)
				return false;
		} else if (!category.equals(other.category))
			return false;
		if (description == null) {
			if (other.description != null)
				return false;
		} else if (!description.equals(other.description))
			return false;
		if (Float.floatToIntBits(lineTotal) != Float.floatToIntBits(other.lineTotal))
			return false;
		if (pCode != other.pCode)
			return false;
		if (pName == null) {
			if (other.pName != null)
				return false;
		} else if (!pName.equals(other.pName))
			return false;
		if (productPrice != other.productPrice)
			return false;
		if (quantity != other.quantity)
			return false;
		if (saleId != other.saleId)
			return false;
		if (sale_date == null) {
			if (other.sale_date != null)
				return false;
		} else if (!sale_date.equals(other.sale_date))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Sale [saleId=" + saleId + ", pCode=" + pCode + ", quantity=" + quantity + ", productPrice="
				+ productPrice + ", category=" + category + ", pName=" + pName + ", description=" + description
				+ ", sale_date=" + sale_date + ", lineTotal=" + lineTotal + "]";
	}

}
