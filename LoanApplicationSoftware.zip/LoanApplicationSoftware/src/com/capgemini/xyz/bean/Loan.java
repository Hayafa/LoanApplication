package com.capgemini.xyz.bean;

public class Loan {

	private long loanID;
	private double loanAmount;
	private long custID;
	private int duration;
	
	public Loan() {
		super();
	}
	
	public Loan(double loanAmount, long custID, int duration) {
		super();
		this.loanAmount = loanAmount;
		this.custID = custID;
		this.duration = duration;
	}

	public Loan(long loanID, double loanAmount, long custID, int duration) {
		super();
		this.loanID = loanID;
		this.loanAmount = loanAmount;
		this.custID = custID;
		this.duration = duration;
	}
	public long getLoanID() {
		return loanID;
	}
	public void setLoanID(long loanID) {
		this.loanID = loanID;
	}
	public double getLoanAmount() {
		return loanAmount;
	}
	public void setLoanAmount(double loanAmount) {
		this.loanAmount = loanAmount;
	}
	public long getCustID() {
		return custID;
	}
	public void setCustID(long custID) {
		this.custID = custID;
	}
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}
	@Override
	public String toString() {
		return "Loan [loanID=" + loanID + ", loanAmount=" + loanAmount + ", custID=" + custID + ", duration=" + duration
				+ "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (custID ^ (custID >>> 32));
		result = prime * result + duration;
		long temp;
		temp = Double.doubleToLongBits(loanAmount);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + (int) (loanID ^ (loanID >>> 32));
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Loan other = (Loan) obj;
		if (custID != other.custID)
			return false;
		if (duration != other.duration)
			return false;
		if (Double.doubleToLongBits(loanAmount) != Double.doubleToLongBits(other.loanAmount))
			return false;
		if (loanID != other.loanID)
			return false;
		return true;
	}
}
