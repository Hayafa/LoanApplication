package com.capgemini.xyz.dao;

import java.util.HashMap;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;
import com.capgemini.xyz.util.DbUtil;

public class LoanDao implements ILoanDao{

	@Override
	public long insertCust(Customer cust) {
		cust.setCustId(DbUtil.CustomerID);
		DbUtil.customerEntry.put((int)cust.getCustId(),cust);
		return cust.getCustId();
	}
	@Override
	public long applyLoan(Loan loan) {
		loan.setLoanID(DbUtil.LoanID);
		DbUtil.loanEntry.put((int)loan.getLoanID(),loan);
		return loan.getLoanID();
	}
	public HashMap<Integer, Customer> customerDetails()
	{
		return DbUtil.getCustCollection();
	}
	public HashMap<Integer, Loan> loanDetails()
	{
		return DbUtil.getLoanCollection();
	}
}
