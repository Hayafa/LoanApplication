package com.capgemini.xyz.util;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;

public class DbUtil {
 
	public static Map<Integer,Customer> customerEntry=new HashMap<Integer,Customer>();
	public static Map<Integer,Loan> loanEntry=new HashMap<Integer,Loan>();
	
	public static long CustomerID=(int)(Math.random()*10000);
	public static long LoanID=(int)(Math.random()*100000);

	public static HashMap<Integer,Customer> getCustCollection() {
		return (HashMap<Integer, Customer>) customerEntry;
	}
	public static HashMap<Integer,Loan> getLoanCollection() {
		return (HashMap<Integer, Loan>)loanEntry;
	}
}
