package com.capgemini.xyz.service;

import java.util.HashMap;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;
import com.capgemini.xyz.exception.InvalidEmailException;
import com.capgemini.xyz.exceptions.InvalidNameException;

public interface ILoanService {

	public long applyLoan(Loan loan);
	Customer validateCustomer(Customer customer) throws InvalidNameException,InvalidEmailException;
	public long insertCust(Customer cust) ;
	public double calculateEMI(double amount, int duration);
	HashMap<Integer, Loan> loanDetails();
	HashMap<Integer, Customer> customerDetails();
}
