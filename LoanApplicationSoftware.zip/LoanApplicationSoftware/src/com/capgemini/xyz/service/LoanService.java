package com.capgemini.xyz.service;

import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;
import com.capgemini.xyz.dao.LoanDao;
import com.capgemini.xyz.exception.InvalidEmailException;
import com.capgemini.xyz.exceptions.InvalidNameException;

public class LoanService implements ILoanService {

	private LoanDao loanDao=new LoanDao();
	
	@Override
	public long insertCust(Customer cust){
		return loanDao.insertCust(cust);
	}
	@Override
	public long applyLoan(Loan loan) {
		return loanDao.applyLoan(loan);
	}
    @Override
	public HashMap<Integer, Customer> customerDetails(){
		return loanDao.customerDetails();
	}
    @Override
	public HashMap<Integer, Loan> loanDetails(){
		return loanDao.loanDetails();
	}
	@Override
	public Customer validateCustomer(Customer customer)throws InvalidNameException, InvalidEmailException {
		
		Pattern p=Pattern.compile("^[a-zA-Z\\\\s]*$");
		Matcher m=p.matcher(customer.getCustName());
		if(m.find())
		{
			String emailVerify = "^[\\w-\\+]+(\\.[\\w]+)*@[\\w-]+(\\.[\\w]+)*(\\.[a-z]{2,})$";
			Pattern p1=Pattern.compile(emailVerify);
			Matcher m1=p1.matcher(customer.getEmail());
			if(m1.find())
			{
				return customer;
			}
			else throw new InvalidEmailException("Invalid Customer Email");
		}
		else throw new InvalidNameException(" Invalid Customer Name");		
	}
	@Override
	public double calculateEMI(double amount, int duration) {
		double rate=(9.5/100);
		return (amount*rate*((1+rate)*duration)/((1+rate)*duration-1));
	}

}
