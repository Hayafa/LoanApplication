package com.capgemini.xyz.ui;

import java.util.Scanner;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;
import com.capgemini.xyz.exception.InvalidEmailException;
import com.capgemini.xyz.exceptions.InvalidNameException;
import com.capgemini.xyz.service.ILoanService;
import com.capgemini.xyz.service.LoanService;

public class ExecuterMain {

	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);
		Customer cust=new Customer();
		Loan loan=new Loan();
		ILoanService service=new LoanService();

		while(true) {
			System.out.println("\n---------------XYZ Finance Company welcomes you:----------------\n"+"1)Register Customer\n2)Exit");
			int choose=sc.nextInt();
			switch(choose)
			{
			case 1:{
				System.out.println("1)Register Customer:");
				System.out.println("Enter customer name: ");
				String custName=sc.next();
				System.out.println("Enter Address: ");
				String custAdd=sc.next();
				System.out.println("Enter Email: ");
				String custMail=sc.next();
				cust=new Customer(custName, custAdd, custMail);
				try {
					service.validateCustomer(cust);
				} catch (InvalidNameException | InvalidEmailException e) {
					e.printStackTrace();System.exit(0);
				}
				
				long custId=0;
	            custId = service.insertCust(cust);
				
				System.out.println("Customer Information saved successfully.\nYour customer Id "
						+ "is <"+custId+">");
				System.out.println("Do you wish to apply for loan?(Yes/No)");
				String loanOption=sc.next();
				if(loanOption.equalsIgnoreCase("Yes"))
				{
					System.out.println("Enter the loan amount");
					double loanAmount=sc.nextDouble();
					System.out.println("Enter the loan duration:");
					int loanDuration=sc.nextInt();
					String loanOption2=null;
					System.out.println("For loan amount <"+loanAmount+"> and <"+loanDuration+"> years duration.\nYour EMI per month will be "
							+service.calculateEMI(loanAmount, loanDuration)+"\nDo you want to apply for loan now?(Yes/No)");
					loanOption2=sc.next();
					if(loanOption2.equalsIgnoreCase("Yes"))
					{
						loan=new Loan(loanAmount, custId, loanDuration);
						long loanId=service.applyLoan(loan);
						System.out.println("Your Loan request is generated.\nYour LoanID is <"+loanId+">/nCustomer Details: "+service.customerDetails()+
								"\nLoanDetails: "+service.loanDetails());
					}
					else if(loanOption2.equalsIgnoreCase("No"))    
					{
						System.out.println("Your loan request is not generated./nDetails of Customer:"+service.customerDetails());
					}
					else
					{
						System.out.println("Invalid Input");
					}
				}
				else if(loanOption.equalsIgnoreCase("No"))
				{
					System.out.println("Details of Customer:"+service.customerDetails());
				}
				else
				{
					System.out.println("Invalid Input");
				}
				break;
			}
			case 2:System.out.println("Status: Exit!");System.exit(0);break;
			default: System.out.println("Invalid Entry: Please Choose your option again!") ;
			}
		}
	}
}

