package com.cg.mra.ui;

import java.util.Scanner;

import com.cg.mra.beans.Account;
import com.cg.mra.exceptions.InvalidMobileNoException;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;

public class MainUI {

	public static void main(String args[]) {

		AccountService service=new AccountServiceImpl();
		Account account=new Account();

		Scanner sc=new Scanner(System.in);
		String mobileNo;
		while(true) {
			System.out.println("\n---------------------Mobile Recharge Application-----------------------");
			System.out.println("\n1) Account Balance Enquiry\n2) Recharge Account\n3)Exit");
			int choose=sc.nextInt();
			switch(choose)
			{
			case 1:	
				System.out.println("\n1)Account Balance Enquiry :\nEnter Mobile No : ");
				mobileNo=sc.next();
				try {
					account=service.getAccountDetails(mobileNo);
					System.out.println("Your Current Balance is : Rs "+account.getAccountBalance());
				}catch(RuntimeException e)
				{
					System.out.println("ERROR: Given Account Id Does Not Exists!");
				}
				break;
			case 2: 
				System.out.println("\n1)Recharge Account:\nEnter Mobile No : ");
				mobileNo=sc.next();
				try {
					account=service.getAccountDetails(mobileNo);
					System.out.println("Enter Recharge Amount : ");
					double rechargeAmount=sc.nextDouble();
					System.out.println("Your Account Recharged Successfully.\nHello "+account.getCustomerName()+", Available Balance is: "
							+service.rechargeAccount(mobileNo, rechargeAmount));
				}catch(RuntimeException e)
				{
					System.out.println("ERROR: Cannot recharge account as given mobile no. does not exists!");
				}
				break;
			case 3: System.out.println("Status: Exit!");System.exit(0);
			default: System.out.println("Invalid Input! Enter your option again.");
			}
		}
	}
}
