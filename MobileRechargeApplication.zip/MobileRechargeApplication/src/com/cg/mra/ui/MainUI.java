package com.cg.mra.ui;

import java.util.Scanner;

import com.cg.mra.beans.Account;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;

public class MainUI {

	public static void main(String args[]) {
		
		AccountService service=new AccountServiceImpl();
		Account account=new Account();
		System.out.println("\n---------------------Mobile Recharge Application-----------------------");
		System.out.println("\n1) Account Balance Enquiry\n2) Recharge Account\n3)Exit");
		Scanner sc=new Scanner(System.in);
		int choose=sc.nextInt();
		switch(choose)
		{
		    case 1: System.out.println("\n1)Account Balance Enquiry Option:\nEnter Mobile No : ");
		                   String mobileNo=sc.next();
		                   account=service.getAccountDetails(mobileNo);
	                      System.out.println("Your Current Balance is : Rs "+account.getAccountBalance());
		    case 2: System.out.println("");
		
		}
	}
}
