package com.cg.mra.service;

import com.cg.mra.beans.Account;
import com.cg.mra.dao.AccountDao;
import com.cg.mra.dao.AccountDaoImpl;
import com.cg.mra.exceptions.InvalidMobileNoException;

public class AccountServiceImpl implements AccountService {

	AccountDao accountDao=new AccountDaoImpl();
	
	@Override
	public Account getAccountDetails(String mobileNo)
	{
	 return accountDao.getAccountDetails(mobileNo);
		
	}

	@Override
	public double rechargeAccount(String mobileNo, double rechargeAmount) {	
		//if(mobileNo==null)  throw new InvalidMobileNoException("ERROR: Cannot recharge account as given mobile no. does not exists!");
		return accountDao.rechargeAccount(mobileNo, rechargeAmount);
		
	}
}
