package com.cg.mra.service;

import com.cg.mra.beans.Account;
import com.cg.mra.dao.AccountDao;
import com.cg.mra.dao.AccountDaoImpl;

public class AccountServiceImpl implements AccountService {

	AccountDao accountDao=new AccountDaoImpl();
	
	@Override
	public Account getAccountDetails(String mobileNo) {
		Account account=accountDao.getAccountDetails(mobileNo);
		if(account!=null)
		return account;
		else throw new Error("ERROR: Given Account Id Does Not Exists!");
	}

	@Override
	public double rechargeAccount(String mobileNo, double rechargeAmount) {	
		return accountDao.rechargeAccount(mobileNo, rechargeAmount);
	}
}
