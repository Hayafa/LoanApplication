package com.cg.mra.exceptions;

public class InvalidMobileNoException extends RuntimeException {

	public InvalidMobileNoException() {
		super();
		
	}
	public InvalidMobileNoException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public InvalidMobileNoException(String message, Throwable cause) {
		super(message, cause);		
	}

	public InvalidMobileNoException(String message) {
		super(message);	
	}

	public InvalidMobileNoException(Throwable cause) {
		super(cause);
	}

}
