package com.cg.mra.dao;

import com.cg.mra.beans.Account;
import com.cg.mra.exceptions.InvalidMobileNoException;

public interface AccountDao {

	Account getAccountDetails(String mobileNo);
	double rechargeAccount(String mobileNo,double rechargeAmount);
}
