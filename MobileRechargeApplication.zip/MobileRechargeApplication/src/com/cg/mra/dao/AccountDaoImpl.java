package com.cg.mra.dao;

import com.cg.mra.beans.Account;
import com.cg.mra.exceptions.InvalidMobileNoException;
import com.cg.mra.util.DbUtil;

public class AccountDaoImpl implements AccountDao {

	@Override
	public Account getAccountDetails(String mobileNo)  {
		return DbUtil.accountEntry.get(mobileNo);
	}

	@Override
	public double rechargeAccount(String mobileNo, double rechargeAmount) throws InvalidMobileNoException {
		Account account=DbUtil.accountEntry.get(mobileNo);
		if(account==null)
		{
		
		double newAmountBal=rechargeAmount+account.getAccountBalance();
		account.setAccountBalance(newAmountBal);
		return account.getAccountBalance();}
		else throw new InvalidMobileNoException("ERROR: Given Account Id Does Not Exists!");
	}

}
