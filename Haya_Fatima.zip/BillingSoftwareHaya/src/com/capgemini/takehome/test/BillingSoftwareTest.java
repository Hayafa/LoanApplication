package com.capgemini.takehome.test;

import javax.naming.InsufficientResourcesException;

import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.takehome.bean.Product;
import com.capgemini.takehome.exceptions.InsufficientProductQuantity;
import com.capgemini.takehome.exceptions.ProductNotFoundException;
import com.capgemini.takehome.service.ProductService;


public class BillingSoftwareTest {

	private static ProductService services;

	@BeforeClass
	public static void setUpTestEnv() {
		services = new ProductService();
	}
	@Before
	public void setUpTestData() {
	
	}
	@Test(expected=Exception.class)
	public void testGetAccountDetailsForInvalidAccountNumber() throws ProductNotFoundException, InsufficientProductQuantity{
		services.getProductDetails(10088,22);	
	}
	@Test
	public void testGetAccountDetailsForValidAccountNumber()throws ProductNotFoundException{
		Product	product=new Product(10001, "Savings", "Active", 5000);
		Product actualProduct= new Product(10001, "Iphone", "Electronic", 45000, 0	,0);
		Assert.assertEquals(product, actualProduct);
	}

}
