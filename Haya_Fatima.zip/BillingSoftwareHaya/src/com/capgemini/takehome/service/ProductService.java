package com.capgemini.takehome.service;

import com.capgemini.takehome.bean.Product;
import com.capgemini.takehome.dao.IProductDAO;
import com.capgemini.takehome.dao.ProductDAO;
import com.capgemini.takehome.exceptions.InsufficientProductQuantity;
import com.capgemini.takehome.exceptions.ProductNotFoundException;

public class ProductService implements IProductService{

	@Override
	public Product getProductDetails(int productCode,int quantProduct) throws InsufficientProductQuantity,
	                                                        ProductNotFoundException {
		Product product =new Product();
		IProductDAO services = new ProductDAO();
		 product = services.getProductDetails(productCode);
		if(services.getProductDetails(productCode)==null)
				throw new ProductNotFoundException("Sorry ! The Product Code <<"+productCode+">> is not available");
		else {
			if(quantProduct>=0) {
		                product.setQuantity(quantProduct);
		            	int lineTotal = (int) (product.getProductPrice()*quantProduct);
		        		product.setLineTotal(lineTotal);
		                return product;
	                   	}
			else throw new InsufficientProductQuantity("Invalid Quantity");
	}
}
}
