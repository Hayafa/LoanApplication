package com.capgemini.takehome.ui;

/* author=Haya Fatima*/
 
import java.util.Scanner;

import com.capgemini.takehome.bean.Product;
import com.capgemini.takehome.service.IProductService;
import com.capgemini.takehome.service.ProductService;

public class Client {
	public static void main(String args[]) {
		Scanner sc =  new Scanner(System.in);
		IProductService services = new ProductService();
		System.out.println("----------------------------------------BILLING SOFTWARE APPLICATION--------------------------------------------------");

		System.out.println("1) Generate Bill by entering Product Code and quantity \n2)Exit");
		System.out.println("Select your option:");
		int input = sc.nextInt(); 
		switch(input) {
		case 1: try {
			         	System.out.println("Enter the product code:-\t");
				        int productCode = sc.nextInt();
				        System.out.println("Enter the quantity:-\t");
				        int quantProduct = sc.nextInt();
			        	Product product =services.getProductDetails(productCode,quantProduct) ;
				        System.out.println(product);
			          }
				   catch(Exception e) {
					   e.printStackTrace();}
		              break;
		case 2: System.exit(0);
		
		default: System.out.println("Invalid Input.");
				
		}
	}
}
